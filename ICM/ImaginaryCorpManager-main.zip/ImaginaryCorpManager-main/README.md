# ImaginaryCorpManager
Current app in dev (current task MVP for a manager moving towards whole website using agile (or agile-like defelopment)

As of yet it has planned both web api and wpf desktop app for sales
