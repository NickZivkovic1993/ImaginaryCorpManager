﻿namespace ICMWPFUserInterface.Library.Helpers
{
    public interface IConfigHelper
    {
        decimal GetTaxRate();
    }
}